from google.appengine.ext import ndb
from google.appengine.ext.webapp import template
from google.appengine.api import urlfetch
import webapp2
import re, os, time, base64, hashlib, json
import datetime
import logging
from uuid import uuid4
import requests
import requests.auth
import string

#Global variables
REDIRECT_URI = "https://cloudFinal-213200.appspot.com/oauth"
STATE = ''
#NOTE ALL KEYS EXTRACTED FOR GITHUB POSTING -- LOCALLY STORED KEYS UNDER 'EXTRACTED_KEYS'
github_ID = ''
github_SECRET = ''

BattleNet_ID = ''
BattleNet_SECRET = ''

github_key_1 = ''
github_key_2 = ''

'''
#Route for handling post-authorization
class OauthHandler(webapp2.RequestHandler):
	def get(self):
		#Extract 'code' from URL after authorization is granted
		logging.debug('The contents of the GET request are: ' + repr(self.request.GET))
		codeS = self.request.get('code')
		codeSS = ''

		#Construct 'data' package to send along with POST request to retrieve authorization code
		auth_params = dict(client_id=github_ID, client_secret=github_SECRET, code=codeS, redirect_uri=REDIRECT_URI)
		data = {
			'code': codeSS,
			'client_id': github_ID,
			'client_secret': github_SECRET,
			#'grant_type': 'authorization_code',
			'redirect_uri': REDIRECT_URI
		}

		#Send package to required URL for auth. code
		r = requests.post('https://github.com/login/oauth/access_token', data=data)
		data = r.json()
		keyS = data['access_token']
		#keySS = ''
		
		#Header will store authorization requirement to retrieve user data from API call
		headers = {"Authorization": "token " + keyS}

		#Send GET request for all data we can retrieve from user within scope, includes auth. code
		respons = requests.get("https://www.googleapis.com/plus/v1/people/me", headers=headers)
		me_json = respons.json()

		#Retrieve assignment required data: Name, Link to Account, and State that was used.
		#Compare constructed state with the returned one, abort if non-matching
		#Probably not efficient but a really neat way to string compare!
		if STATE2.find(STATE) != -1:
			template_values = {
				'displayN': 'fill',
				'url': 'fill',
				'state': 'fill',
				'bToken': me_json
			}
			path = os.path.join(os.path.dirname(__file__), 'returned.html')
			self.response.out.write(template.render(path, template_values))
		else:
			self.response.write('State code mismatch, aborting request')


# [START main_page]
class MainPage(webapp2.RequestHandler):
	def get(self):
		#Construct random state key based on SHA256 
		STATE = hashlib.sha256(os.urandom(1024)).hexdigest()
		template_values = {
			'client_id': CLIENT_ID,
			'reddit_ID': github_ID,
			'state': STATE
		}
		path = os.path.join(os.path.dirname(__file__), 'index.html')
		self.response.out.write(template.render(path, template_values))
'''
# [END main_page]

class User(ndb.Model):
	name = ndb.StringProperty()
	ownership = ndb.IntegerProperty()
	idVar = ndb.StringProperty()
	email = ndb.StringProperty()
	location = ndb.StringProperty()



class PlayerCharacter(ndb.Model):
	ownership = ndb.IntegerProperty(required=True)
	idVar = ndb.StringProperty()
	name = ndb.StringProperty(required=True)
	realm = ndb.StringProperty(required=True)
	locale = ndb.StringProperty(required=True)
	private = ndb.BooleanProperty()


class UserProfile(webapp2.RequestHandler):
	def get(self, id=None):
		if id:
			user = ndb.Key(urlsafe=id).get()
			user_dict = user.to_dict()
			holder = 0

			current_user = self.request.headers
			for value in current_user:
				if value == 'Owner':
					if str(current_user['Owner']) == str(user.ownership):
						holder = 1

			if holder != 1:
				user_dict['ownership'] = "Access Denied"

			user_dict['idVar'] = "/user/" + id
			self.response.write(json.dumps(user_dict))
		else:
			#Check if header contains ownership key
			current_user = self.request.headers
			holder = 0
			for value in current_user:
				if value == 'Owner':
					holder = 1

			ancestor_key = User.query().fetch()
			for user in ancestor_key:
				temp = user.to_dict()
				temp['idVar'] = "/user/" + str(user.idVar)
				#If an Owner key is present
				if holder != 0:
					#Check if key matches with current profile being checked
					#If they match display the ownership key in query
					if str(temp['ownership']) == str(current_user['Owner']):
						self.response.write(json.dumps(temp))
						self.response.write('\n')
					#If they don't match it isn't their account, mask the ownership key
					else:
						temp['ownership'] = "access denied"
						self.response.write(json.dumps(temp))
						self.response.write('\n')
				#No key provided for Ownership will result in all ownership properties being masked
				else:
					temp['ownership'] = "requires owner key"
					self.response.write(json.dumps(temp))
					self.response.write('\n')

	def post(self):
		parent_key = ndb.Key(User, "parent_user")
		#user_data = json.loads(self.request.body)

		ancestor_key = User.query().fetch()
		user_count = 0
		header = {}

		#For the requirements of this assignment we are assuming that the user has already authenticated
		#	through other means and we are providing two hard coded access keys to these accounts.
		#Check total number of accounts to determine what key is to be provided.
		for user in ancestor_key:
			user_count += 1
		if user_count % 2 == 0:
			#Even value use first key
			header = {'Authorization': 'token ' + github_key_1}
		else:
			#Odd value use second key
			header = {'Authorization': 'token ' + github_key_2}
		
		#Submit token for GitHub account information
		authorization = urlfetch.fetch(
			url='https://api.github.com/user',
			method=urlfetch.GET,
			headers=header) 
		gitReturn = json.loads(authorization.content)

		new_user = User(name=gitReturn['name'], ownership=gitReturn['id'], email=gitReturn['email'], parent=parent_key)
		new_user.put()

		userID = ndb.Key(urlsafe=new_user.key.urlsafe()).get()
		userID.idVar = new_user.key.urlsafe()
		userID.put()

		user_dict = new_user.to_dict()
		user_dict['idVar'] = '/user/' + new_user.key.urlsafe()

		self.response.write(json.dumps(user_dict))

	def patch(self, id=None):
		if id:
			key = ndb.Key(urlsafe=id).get()
			user_data = json.loads(self.request.body)
			warning = 0

			char = ndb.Key(urlsafe=id).get()
			char_dict = char.to_dict()

			current_user = self.request.headers
			own_temp = 0
			for value in current_user:
				if value == "Owner":
					if str(char_dict['ownership']) == str(current_user['Owner']):
						own_temp = 1

			if own_temp == 1:
				for prop in user_data:
					if prop == 'name':
						key.name = user_data['name']
					if prop == 'ownership':
						warning = 1
						self.response.set_status(403)
						self.response.write('Ownership properties are not permitted to be changed by users.\n')
					if prop == 'idVar':
						warning = 1
						self.response.set_status(403)
						self.response.write('OidVar properties are not permitted to be changed by users.\n')
					if prop == 'email':
						key.email = user_data['email']
					if prop == 'location':
						key.location = user_data['location']
			else:
				warning = 1
				self.response.write('Requires accompanying ownership token')
				self.response.set_status(403)
			if warning != 1:
				key.put()

				user_dict = key.to_dict()
				user_dict['idVar'] = "/user/" + str(key.idVar)

				self.response.write(json.dumps(user_dict))

	def delete(self, id=None):
		if id:
			user = ndb.Key(urlsafe=id).get()
			user_dict = user.to_dict()

			current_user = self.request.headers
			holder = 0
			for value in current_user:
				if value == 'Owner':
					holder = 1
			if holder != 0:
				#Check if key matches with current profile being checked
				#If they match display the ownership key in query
				if str(user_dict['ownership']) == str(current_user['Owner']):
					user = ndb.Key(urlsafe=id).get()
					user.key.delete()
				#If they don't match it isn't their account, deny deletion
				else:
					self.response.write('Invalid Ownership Token')
					self.response.set_status(403)
			#No key provided for Ownership will result in all ownership properties being masked
			else:
				self.response.write('Requires accompanying ownership token')
				self.response.set_status(403)

class CharLookup(webapp2.RequestHandler):
	def get(self, id=None):
		if id:
			char = ndb.Key(urlsafe=id).get()
			char_dict = char.to_dict()
			#If provided character is not private then display
			if char_dict['private'] == False:
				current_user = self.request.headers
				holder = 0
				does_it_exist = 0
				for value in current_user:
					if value == 'Owner':
						does_it_exist = 1
				if does_it_exist == 1:
					if str(current_user['Owner']) == str(char_dict['ownership']):
						holder = 1
				char_dict['idVar'] = "/character/" + id
				if holder != 1:
					char_dict['ownership'] = "Access Denied"
				self.response.write(json.dumps(char_dict))
			#If provided character sheet is private then require owner token
			else:
				current_user = self.request.headers
				holder = 0
				match = 0
				for value in current_user:
					if value == 'Owner':
						if str(current_user['Owner']) == str(char_dict['ownership']):
							match = 1
						holder = 1
				if holder !=0:
					if str(char_dict['ownership']) == str(current_user['Owner']):
						char_dict['idVar'] = "/character/" + id
						if match != 1:
							char_dict['ownership'] = "Access Denied"
						self.response.write(json.dumps(char_dict))
					else:
						self.response.write('Requires accompanying ownership token')
						self.response.set_status(403)
				else:
					self.response.write('Requires accompanying ownership token')
					self.response.set_status(403)	

		else:
			ancestor_key = PlayerCharacter.query().fetch()
			current_user = self.request.headers
			match = 0
			for value in current_user:
				if value == 'Owner':
					match = 1
			for char in ancestor_key:
				temp = char.to_dict()
				if match != 0:
					if str(temp['ownership']) == str(current_user['Owner']):
						match = 2
				if temp['private'] == False:
					if match == 2:
						temp['idVar'] = "/character/" + str(char.idVar)
						self.response.write(json.dumps(temp))
						self.response.write('\n')
					else:
						temp['idVar'] = "/character/" + str(char.idVar)
						temp['ownership'] = "Access Denied"
						self.response.write(json.dumps(temp))
						self.response.write('\n')


	def post(self):
		current_user = self.request.headers
		own_temp = 0
		for value in current_user:
			if value == current_user['Owner']:
				own_temp = 1

		if own_temp != 1:
			parent_key = ndb.Key(PlayerCharacter, "parent_character")
			char_data = json.loads(self.request.body)

			ancestor_key = PlayerCharacter.query().fetch()
			char_duplicate = 0
			for char in ancestor_key:
				if char_data['name'] == char.name:
					if char_data['realm'] == char.realm:
						char_duplicate = 1
			if char_duplicate != 1:
				new_char = PlayerCharacter(name=char_data['name'], realm=char_data['realm'], locale=char_data['locale'], ownership=int(current_user['Owner']), private=True, parent=parent_key)
				new_char.put()

				charID = ndb.Key(urlsafe=new_char.key.urlsafe()).get()
				charID.idVar = new_char.key.urlsafe()
				charID.put()

				char_dict = new_char.to_dict()
				char_dict['idVar'] = '/character/' + new_char.key.urlsafe()

				self.response.write(json.dumps(char_dict))
			else:
				self.response.write('Character/Realm combination already exists')
				self.response.set_status(403)
		else:
			self.response.write('Invalid Ownership Token')
			self.response.set_status(403)

	def patch(self, id=None):
		if id:
			key = ndb.Key(urlsafe=id).get()
			char = ndb.Key(urlsafe=id).get()
			char_dict = char.to_dict()

			warning = 0

			user_data = json.loads(self.request.body)

			current_user = self.request.headers
			own_temp = 0
			for value in current_user:
				if value == "Owner":
					if str(char_dict['ownership']) == str(current_user['Owner']):
						own_temp = 1

			if own_temp == 1:
				if str(char_dict['ownership']) == str(current_user['Owner']):
					for prop in user_data:
						if prop == 'name':
							key.name = user_data['name']
						if prop == 'ownership':
							warning = 1
							self.response.set_status(403)
							self.response.write('Ownership properties are not permitted to be changed by users.')
						if prop == 'idVar':
							warning = 1
							self.response.set_status(403)
							self.response.write('idVar properties are not permitted to be changed by users.')
						if prop == 'realm':
							key.realm = user_data['realm']
						if prop == 'locale':
							key.locale = user_data['locale']
						if prop == 'private':
							key.private = user_data['private']
					if warning != 1:
						key.put()

						char_dict = key.to_dict()
						char_dict['idVar'] = "/character/" + str(key.idVar)

						self.response.write(json.dumps(char_dict))
				else:
					self.response.write('Invalid Ownership Token')
					self.response.set_status(403)
			else:
				self.response.write('Requires Ownership Token')
				self.response.set_status(403)


	def delete(self, id=None):
		if id:
			user = ndb.Key(urlsafe=id).get()
			user_dict = user.to_dict()

			current_user = self.request.headers
			holder = 0
			for value in current_user:
				if value == 'Owner':
					holder = 1
			if holder != 0:
				#Check if key matches with current profile being checked
				#If they match display the ownership key in query
				if str(user_dict['ownership']) == str(current_user['Owner']):
					user = ndb.Key(urlsafe=id).get()
					user.key.delete()
				#If they don't match it isn't their account, deny deletion
				else:
					self.response.write('Invalid Ownership Token')
					self.response.set_status(403)
			#No key provided for Ownership will result in all ownership properties being masked
			else:
				self.response.write('Requires accompanying ownership token')
				self.response.set_status(403)

class Profile(webapp2.RequestHandler):
	def get(self):
		current_user = self.request.headers
		requirement = 0
		holder = 0
		permission_granted = 0

		for value in current_user:
			if value == 'Owner':
				holder = 1
			if value == 'Name':
				requirement = requirement + 1
			if value == 'Realm':
				requirement = requirement + 1
			if value == 'Locale':
				requirement = requirement + 1

		ancestor_key = PlayerCharacter.query().fetch()
		if requirement == 3:
			for char in ancestor_key:
				char_found = 0
				if current_user['Name'] == char.name:
					if current_user['Realm'] == char.realm:
						if current_user['Locale'] == char.locale:
							char_found = 1

				if char_found == 1:
					if char.private == True:
						#Private, require matching ownership key
						if holder == 1:
							if str(current_user['Owner']) == str(char.ownership):
								#Matching key found, carry out query
								permission_granted = 1
							else:
								self.response.write('Invalid Ownership Token')
								self.response.set_status(403)
						else:
							self.response.write('Requires accompanying ownership token')
							self.response.set_status(403)
					else:
						#Not private, public query allowed
						permission_granted = 1

		if permission_granted == 1:
				query = urlfetch.fetch(
					url='https://us.api.battle.net/wow/character/' + current_user['Realm'] + '/' + current_user['Name'] + '?locale=' + current_user['Locale'] + '&apikey=' + BattleNet_ID,
					method=urlfetch.GET,
					)
				queryReturn = json.loads(query.content)
				self.response.write(queryReturn)
		else:
			self.response.write('Unable to complete request')
			self.response.set_status(403)

class Appearance(webapp2.RequestHandler):
	def get(self):
		current_user = self.request.headers
		requirement = 0
		holder = 0
		permission_granted = 0

		for value in current_user:
			if value == 'Owner':
				holder = 1
			if value == 'Name':
				requirement = requirement + 1
			if value == 'Realm':
				requirement = requirement + 1
			if value == 'Locale':
				requirement = requirement + 1

		ancestor_key = PlayerCharacter.query().fetch()
		if requirement == 3:
			for char in ancestor_key:
				char_found = 0
				if current_user['Name'] == char.name:
					if current_user['Realm'] == char.realm:
						if current_user['Locale'] == char.locale:
							char_found = 1

				if char_found == 1:
					if char.private == True:
						#Private, require matching ownership key
						if holder == 1:
							if str(current_user['Owner']) == str(char.ownership):
								#Matching key found, carry out query
								permission_granted = 1
							else:
								self.response.write('Invalid Ownership Token')
								self.response.set_status(403)
						else:
							self.response.write('Requires accompanying ownership token')
							self.response.set_status(403)
					else:
						#Not private, public query allowed
						permission_granted = 1

		if permission_granted == 1:
				query = urlfetch.fetch(
					url='https://us.api.battle.net/wow/character/' + current_user['Realm'] + '/' + current_user['Name'] + '?fields=appearance' + '&locale=' + current_user['Locale'] +'&apikey=' + BattleNet_ID,
					method=urlfetch.GET,
					)
				queryReturn = json.loads(query.content)
				self.response.write(queryReturn)
		else:
			self.response.write('Unable to complete request')
			self.response.set_status(403)

class Stats(webapp2.RequestHandler):
	def get(self):
		current_user = self.request.headers
		requirement = 0
		holder = 0
		permission_granted = 0

		for value in current_user:
			if value == 'Owner':
				holder = 1
			if value == 'Name':
				requirement = requirement + 1
			if value == 'Realm':
				requirement = requirement + 1
			if value == 'Locale':
				requirement = requirement + 1

		ancestor_key = PlayerCharacter.query().fetch()
		if requirement == 3:
			for char in ancestor_key:
				char_found = 0
				if current_user['Name'] == char.name:
					if current_user['Realm'] == char.realm:
						if current_user['Locale'] == char.locale:
							char_found = 1

				if char_found == 1:
					if char.private == True:
						#Private, require matching ownership key
						if holder == 1:
							if str(current_user['Owner']) == str(char.ownership):
								#Matching key found, carry out query
								permission_granted = 1
							else:
								self.response.write('Invalid Ownership Token')
								self.response.set_status(403)
						else:
							self.response.write('Requires accompanying ownership token')
							self.response.set_status(403)
					else:
						#Not private, public query allowed
						permission_granted = 1

		if permission_granted == 1:
				query = urlfetch.fetch(
					url='https://us.api.battle.net/wow/character/' + current_user['Realm'] + '/' + current_user['Name'] + '?fields=statistics' + '&locale=' + current_user['Locale'] +'&apikey=' + BattleNet_ID,
					method=urlfetch.GET,
					)
				queryReturn = json.loads(query.content)
				self.response.write(queryReturn)
		else:
			self.response.write('Unable to complete request')
			self.response.set_status(403)

class Titles(webapp2.RequestHandler):
	def get(self):
		current_user = self.request.headers
		requirement = 0
		holder = 0
		permission_granted = 0

		for value in current_user:
			if value == 'Owner':
				holder = 1
			if value == 'Name':
				requirement = requirement + 1
			if value == 'Realm':
				requirement = requirement + 1
			if value == 'Locale':
				requirement = requirement + 1

		ancestor_key = PlayerCharacter.query().fetch()
		if requirement == 3:
			for char in ancestor_key:
				char_found = 0
				if current_user['Name'] == char.name:
					if current_user['Realm'] == char.realm:
						if current_user['Locale'] == char.locale:
							char_found = 1

				if char_found == 1:
					if char.private == True:
						#Private, require matching ownership key
						if holder == 1:
							if str(current_user['Owner']) == str(char.ownership):
								#Matching key found, carry out query
								permission_granted = 1
							else:
								self.response.write('Invalid Ownership Token')
								self.response.set_status(403)
						else:
							self.response.write('Requires accompanying ownership token')
							self.response.set_status(403)
					else:
						#Not private, public query allowed
						permission_granted = 1

		if permission_granted == 1:
				query = urlfetch.fetch(
					url='https://us.api.battle.net/wow/character/' + current_user['Realm'] + '/' + current_user['Name'] + '?fields=titles' + '&locale=' + current_user['Locale'] +'&apikey=' + BattleNet_ID,
					method=urlfetch.GET,
					)
				queryReturn = json.loads(query.content)
				self.response.write(queryReturn)
		else:
			self.response.write('Unable to complete request')
			self.response.set_status(403)		


allowed_methods = webapp2.WSGIApplication.allowed_methods
new_allowed_methods = allowed_methods.union(('PATCH',))
webapp2.WSGIApplication.allowed_methods = new_allowed_methods

# [START app]
app = webapp2.WSGIApplication([
    #('/', MainPage),
	#('/oauth', OauthHandler),
	('/user', UserProfile),
	('/user/(.*)', UserProfile),
	('/character', CharLookup),
	('/character/(.*)', CharLookup),
	('/profile', Profile),
	('/appearance', Appearance),
	('/statistics', Stats),
	('/titles', Titles)
], debug=True)
# [END app]