from google.appengine.ext import ndb
from google.appengine.ext.webapp import template
import webapp2
import re, os, time, base64, hashlib, json
import logging
from uuid import uuid4
import requests
import string

#Global variables
CLIENT_ID = ""
CLIENT_SECRET = ""
REDIRECT_URI = "https://w4-oauth.appspot.com/oauth"
SCOPE = 'email'
LEAD_URL = 'https://accounts.google.com/o/oauth2/v2/auth'
full_url = ''
ACCESS = ''
AUTHORIZATION = ''
STATE = ''

#Route for handling post-authorization
class OauthHandler(webapp2.RequestHandler):
	def get(self):
		#Extract 'code' from URL after authorization is granted
		logging.debug('The contents of the GET request are: ' + repr(self.request.GET))
		codeS = self.request.get('code')

		#Construct 'data' package to send along with POST request to retrieve authorization code
		auth_params = dict(client_id=CLIENT_ID, client_secret=CLIENT_SECRET, code=codeS, redirect_uri=REDIRECT_URI, grant_type='authorization_code')
		data = {
			'code': codeS,
			'client_id': CLIENT_ID,
			'client_secret': CLIENT_SECRET,
			'redirect_uri': REDIRECT_URI,
			'grant_type': 'authorization_code'
		}

		#Send package to required URL for auth. code
		r = requests.post('https://www.googleapis.com/oauth2/v4/token', data=data)
		data = r.json()
		keyS = data['access_token']
		
		#Header will store authorization requirement to retrieve user data from API call
		headers = {"Authorization": "Bearer " + keyS}

		#Send GET request for all data we can retrieve from user within scope, includes auth. code
		respons = requests.get("https://www.googleapis.com/plus/v1/people/me", headers=headers)
		me_json = respons.json()

		#Retrieve assignment required data: Name, Link to Account, and State that was used.
		displayName = me_json['displayName']
		url = me_json['url']
		STATE2 = self.request.get('state')
		#Compare constructed state with the returned one, abort if non-matching
		#Probably not efficient but a really neat way to string compare!
		if STATE2.find(STATE) != -1:
			template_values = {
				'displayN': displayName,
				'url': url,
				'state': STATE2
			}
			path = os.path.join(os.path.dirname(__file__), 'returned.html')
			self.response.out.write(template.render(path, template_values))
		else:
			self.response.write('State code mismatch, aborting request')


# [START main_page]
class MainPage(webapp2.RequestHandler):
	def get(self):
		#Construct random state key based on SHA256 
		STATE = hashlib.sha256(os.urandom(1024)).hexdigest()
		template_values = {
			'client_id': CLIENT_ID,
			'state': STATE
		}
		path = os.path.join(os.path.dirname(__file__), 'index.html')
		self.response.out.write(template.render(path, template_values))

# [END main_page]

allowed_methods = webapp2.WSGIApplication.allowed_methods
new_allowed_methods = allowed_methods.union(('PATCH',))
webapp2.WSGIApplication.allowed_methods = new_allowed_methods

# [START app]
app = webapp2.WSGIApplication([
    ('/', MainPage),
	('/oauth', OauthHandler),
], debug=True)
# [END app]